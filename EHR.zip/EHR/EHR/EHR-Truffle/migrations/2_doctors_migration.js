const Doctors = artifacts.require("DoctorsContract.sol");
        module.exports = function (deployer) {
          deployer.deploy(Doctors);
        };
        